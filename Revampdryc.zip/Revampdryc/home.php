<!doctype html>
<html>

<title>REVAMP Dry-Cleaner And Laundry Services</title>
<style>
.container {
  position: relative;
  width: 50%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.3;
}

.container:hover .middle {
  opacity: 1;
}

.text {
  background-color: #4CAF50;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
}
</style>
<ul>
<link rel="stylesheet" href="roan1.css">
<link rel="shortcut icon" href="p/rd.ico" width="100px"/>
<div>
<a data-tu-do="buttonFollow" data-tu-icon="square" data-tu-size="26" data-tu-profile="yes" data-tu-pos="top" href="https://www.trepup.com/roanservices">ROAN Services</a><script type="text/javascript" src="https://d133y3pkmbn288.cloudfront.net/web/javascripts/widgetjs/tu-8.js"></script>
<table width="900px">
<tr>
<td style=text-align:center;color:white;><img src="PH.PNG" WIDTH="20PX"> +254 789 489 752 /+254 712 225 621 |<img src="E.PNG" WIDTH="20PX">revampdryc@gmail.com</td>
<td><a href="http://www.facebook.com"><img src="f.png" width="40px"></a><a href="http://www.twitter.com"><img src="twi.png" width="40px"></a><a href="http://www.google.com"><img src="g.png" width="24px"></a></td>
<td><h2 style=font-size:12px;>Mon-Sat:7am-7pm</h2></td>
</tr>
</table>
</div>

<body>
<table width="1000px" align="center" style= background-image:url("pic/dv1.jpg");>

<td style="text-align:center;">  <img src="pic/rep.png" width="250px" height="180px" align="middle"></td>
<td style=font-family:bold;><div class="navbar">
  <a href="home.php">Home</a></B>
  <a href="aboutus.php">About Us</a>
  <div class="dropdown">
    <button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Dry-Cleaning Service's 
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="ss.php">Suit Cleaning</a></li>
     <li><a href="cs.php">Curtain Cleaning</a></li>
     <li> <a href="cdc.php">Comforter And Duvet Cleaning</a></li>
	 <br>
	 <br>
	 
	 <li> <a href="sp.php">Steaming and Pressing</a><li>
	  <li><a href="lss.php">Laundered Shirt Service </a></li>
	  <br>
	  <br>
	  <li><a href="lc.php">Leather Cleaning</a></li>
	 <li><a href="ssc.php">Sport Shoe Cleaning</a></li>
	  <li><a href="gc.php">Gown Cleaning </a></li>
	  <br>
	  <br>
	  <li><a href="uni.php">Uniform's Cleaning Service's</a></li>
	 <li><a href="tw.php">Towel's Cleaning Service's</a></li>
	  </ul>
    </div>
  </div> 
  <div class="dropdown">
	<button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Home Cleaning Service's
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="so.php">Sofa Cleaning</a></li>
	 <li> <a href="kk.php">Kitchen Appliances and KitchenWare Cleaning</a></li>
	 <br>
	 <br>
     <li><a href="cc.php">Carpet Cleaning</a></li>
     
	 <li> <a href="ma.php">Mattress Cleaning</a></li>
	 </ul>
	 </div>
	 </div>
  <a href="Fs.php">Fumigation and Pest Control Service's</a>
   <a href="wu.php">Why Us</a>
    <a href="cu.php">Contacts</a>
	
	
</div>
	
</div>

</td>

</table>
</ul>
<table width="800px" height="15px" align="center">
<tr>

<tr>
<td>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<body>
<div class="w3-content w3-section" style="max-width:500px;background-color:white" >
<a href="home.php"><img class="mySlides" class="center"src="pic/rep.png"style="width:900px;height:400px" align="center">
 <a  href="lss.php" ><img class= "mySlides" class="center"src="p/lss12.png" style="width:900Px;height:400px" ></a>
  <a href="cdc.php"> <img class="mySlides" class="center" src="pic/dv16.png" style="width:900px;height:400px;" ></a>
  <a href="home.php"> <img class="mySlides" class="center"  src="p/d12.jpg" style="width:800px;height:400px"></a>
 <a href="fs.php"><img class="mySlides" class="center" src="p/f11.PNG" style="width:800px;height:400px"></a>
   <a href="ss.php"><img class="mySlides"class="center" src="pic/scs1.png" style="width:800px;height:400px"></a>
 <a href="cs.php"><img class="mySlides"class="center" src="pic/c10.png" style="width:900px; height:400px"></a>
 <a href="lc.php"><img class="mySlides"class="center" src="p/l10.png" style="width:900px; height:400px" align="center"></a>
 <a href="uni.php"><img class="mySlides"class="center" src="p/u10.png" style="width:900px; height:400px"></a>
 <a href="tw.php"><img class="mySlides"class="center" src="p/t20.png" style="width:900px; height:400px"></a>
 <a href="ssc.php"><img class="mySlides"class="center" src="p/ss10.png" style="width:900px; height:400px"></a>
 <a href="gc.php"><img class="mySlides"class="center" src="p/GG1.JPG" style="width:700px; height:400px"></a>
 <a href="so.php"><img class="mySlides"class="center" src="h/ca11.png" style="width:900px; height:400px"></a>
 <a href="cc.php"><img class="mySlides"class="center" src="h/c20.png" style="width:900px; height:400px"></a>
 <a href="kk.php"><img class="mySlides"class="center" src="h/ka.png" style="width:900px; height:400px"></a>
 <a href="ma.php"><img class="mySlides"class="center" src="h/MAT1.png" style="width:900px; height:400px"></a>
 <img class="mySlides"class="center" src="h/p.png" style="width:900px; height:400px">
</div>
</table>
<script>
var myIndex = 0;
carousel();


function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    

x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 5000); // Change image every 5 seconds
}
</script>
</div>
<body>
<h1 style=font-size:20px;>Our Dry Cleaning And Fumigation Service's</h1>
<table width="600px" align="center">
<tr>
<div class="container">
<td><a href="ss.php" style=background-color:white; ><img src="pic/s2.jpg" alt="Avatar" class="image" style="width:100%"></a></td>
<div class="middle">
    <div class="text">Suit Cleaning Service's</div>
  </div>
</div>
<td><a href="cs.php"style=background-color:white; ><img src="pic/c1.jpg"></a></td>
<td><a href="cdc.php" style=background-color:white;><img src="pic/dv1.jpg" width="200px"></a></td>
</tr>
<tr>
<td style=background-color:white;color:white;font-size:15px;><a href="ss.php"> Suit Cleaning Service's</a></td>
<td style=background-color:white;color:white;font-size:15px;><a href="cs.php">Curtain Cleaning Service's </a></td>
<td style=background-color:white;color:white;font-size:14px;><a href="cdc.php">Comforter and Duvet Cleaning</a></td>
</tr>
<tr>
<br>
<br>
<td><a href="home.php" style=background-color:white; ><img src="p/d12.jpg"></a></td>
<td><a href="lss.php" style=background-color:white;  ><img src="p/d2.jpg"></a></td>
<td><a href="sp.php" style=background-color:white;  ><img src="pic/sp1.jpg" width="200px"></a></td>
</tr>
<tr>
<td style=background-color:white;color:white;font-size:15px;><a href="home.php">Dry Cleaning Services</a></td>
<td style=background-color:white;color:white;font-size:15px;><a href="lss.php">Laundered Shirt Service</a></td>
<td style=background-color:white;color:white;font-size:15px;><a href ="sp.php">Steaming and 
Pressing Services</a></td>
</tr>
<tr>
<br>
<br>
<td><a href="lc.php" style=background-color:white; ><img src="p/L2.jpg"></a></td>
<td><a href="ssc.php" style=background-color:white;  ><img src="p/so2.jpg"></a></td>
<td><a href="gc.php" style=background-color:white;  ><img src="p/g3.jpg" width="200px"></a></td>
</tr>

<tr>
<td style=background-color:white;color:white;font-size:15px;><a href="lc.php">Leather Cleaning Service's</a></td>
<td style=background-color:white;color:white;font-size:15px;><a href="ssc.php">Sport Shoe's Cleaning Service's</a></td>
<td style=background-color:white;color:white;font-size:15px;><a href ="gc.php">Gown Cleaning Service's</a></td>
</tr>
<tr>
<br>
<br>
<td><a href="uni.php" style=background-color:white; ><img src="p/c1.jpg"></a></td>
<td><a href="tw.php" style=background-color:white;  ><img src="p/t1.jpg"></a></td>
<td><a href="fS.php" style=background-color:white;  ><img src="p/f2.jpg"></a></td>
</tr>

<tr>
<td style=background-color:white;color:white;font-size:15px;><a href="uni.php">Uniform Cleaning Service's </a></td>
<td style=background-color:white;color:white;font-size:15px;><a href="tw.php">Towel's Cleaning Service's</a></td>
<td style=background-color:white;color:white;font-size:15px;><a href="fs.php">Fumigation Control Service's</a></td>
</tr>
<tr>
<td>
</td>
</tr>
<tr>
<td><a href="uni.php" style=background-color:white; ><img src="h/sf1.jpg" width="300px"></a></td>
<td><a href="tw.php" style=background-color:white;  ><img src="h/ca2.jpg"width="300px" ></a></td>
<td><a href="fS.php" style=background-color:white;  ><img src="h/ka5.jpg"width="200px" height="160px"></a></td>
</tr>
<tr>
<td>
</td>
</tr>
<tr>
<td style=background-color:white;color:white;font-size:15px;><a href="so.php">Sofa's and Couch's Cleaning Service's</a></td>
<td style=background-color:white;color:white;font-size:15px;><a href="cc.php">Carpet Cleaning Service's</a></td>
<td style=background-color:white;color:white;font-size:13px;><a href="kk.php">Kitchen Appliances Cleaning Service's</a></td>
</tr>
</table>
</body>
<br>
<div style=background-color:black>
<table width="980px" align="center">
<tr>
<th style=color:red;background-color:white;text-align:center;>Quick Contacts</th>
<th style=color:red; ></th>
<th style=color:red;background-color:white;text-align:center; >Service's</th>
<th style=color:red; ></th>
<th style=color:red; ></th>
<th style=color:red;background-color:white; >Social Media</th>
</tr>
<tr><td style=color:white;font-size:12px;>

<h3>
<b>
<li><img src="lo.PNG" WIDTH="20PX"> DAVEKON PALACE,Banana Town Room NO:G2</li><br>
<li><img src="PH.PNG" WIDTH="20PX"> Phone:+254 789 489 752 /+254 712 225 621</li><br>
<li><img src="E.PNG" WIDTH="20PX"> Email:revampdryc@gmail.com</li></td>
<br>
<td style=color:white;font-size:10px;><u><b><h4 style=text-align:center;>
<li><a href ="ss.php">Suit Cleaning </a></li><br><br>
<LI><a href ="cs.php">Curtain Cleaning</a></Li><br><br>
<LI><a href ="cdc.php">Comforters And Duvet</a></LI> <br><br>
<li><a href ="sp.php">Steaming and   Pressing</a></li><br>
</TD>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="home.php">Dry Cleaning</a></li><br>
<li><a href ="lss.php">Laundered Shirt</a></li><br><br>
<li><a href ="fs.php">Fumigation control</a></li><br>
<li><a href="uni.php">Uniform's Cleaning </a></li><br>
</td>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="lc.php">Leather Cleaning</a></li><br>
<li><a href ="ssc.php">Sport Shoe Cleaning </a></li><br>
<li><a href ="gc.php">Gown Cleaning</a></li><br>
<li><a href="tw.php">Towel's Cleaning</a></li>
</h4>
</td>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="so.php">Sofa Cleaning</a></li><br>
<li><a href ="cc.php">Carpet Cleaning </a></li><br>
<li><a href ="kk.php">Kitchen Appliances Cleaning</a></li><br><br>
<li> <a href="ma.php">Mattress Cleaning</a></li>
</h4>
</td>
<td style=color:white;font-size:8px;>
<td><a href="http://www.facebook.com"><img src="f.png" width="40px"></a><br><h2 style =font-size:5px;>|</h2><a href="http://www.twitter.com"><img src="twi.png" width="40px"></a><br><h2 style =font-size:5px;>|</h2><a href="http://www.google.com"><img src="g.png" width="24px"></a></td>
</tr>
</table>
</html>
