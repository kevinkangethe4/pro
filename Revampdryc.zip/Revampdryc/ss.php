<!doctype html>
<html>
<title>Suit Cleaning Services|REVAMP Dry-Cleaner And Laundry Services</title>
<ul>
<link rel="stylesheet" href="roan1.css">
<link rel="shortcut icon" href="p/rd.ico" width="100px"/>

<div>

<table width="980px">
<tr>
<td style=text-align:center;color:white;><img src="PH.PNG" WIDTH="20PX"> +254 789 489 752 /+254 712 225 621|<img src="E.PNG" WIDTH="20PX">info@roanservices.com</td>
<td><a href="http://www.facebook.com"><img src="f.png" width="40px"></a><a href="http://www.twitter.com"><img src="twi.png" width="40px"></a><a href="http://www.google.com"><img src="g.png" width="24px"></a></td>
<td><h2 style=font-size:12px;>Mon-Sat:7am-7pm</h2></td>
</tr>
</table>
</div>

<body>
<table width="1000px" align="center" style= background-image:url("pic/dv1.jpg");>

<td style="text-align:center;">  <img src="pic/rep.png" width="250px" height="180px" align="middle"></td>
<td style=font-family:bold;><div class="navbar">
  <a href="home.php">Home</a></B>
  <a href="aboutus.php">About Us</a>
  <div class="dropdown">
    <button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Dry-Cleaning Service's 
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="ss.php">Suit Cleaning</a></li>
     <li><a href="cs.php">Curtain Cleaning</a></li>
     <li> <a href="cdc.php">Comforter And Duvet Cleaning</a></li>
	 <br>
	 <br>
	 
	 <li> <a href="sp.php">Steaming and Pressing</a><li>
	  
	  <li><a href="lss.php">Laundered Shirt Service </a></li>
	  <br>
	  <br>
	  <li><a href="lc.php">Leather Cleaning</a></li>
	 <li><a href="ssc.php">Sport Shoe Cleaning</a></li>
	  <li><a href="gc.php">Gown Cleaning </a></li>
	  <br>
	  <br>
	  <li><a href="uni.php">Uniform's Cleaning Service's</a></li>
	 <li><a href="tw.php">Towel's Cleaning Service's</a></li>
	  </ul>
    </div>
  </div> 
  <div class="dropdown">
	<button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Home Cleaning Service's
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="so.php">Sofa Cleaning</a></li>
	 <li> <a href="kk.php">Kitchen Appliances and KitchenWare Cleaning</a></li>
	 <br>
	 <br>
     <li><a href="cc.php">Carpet Cleaning</a></li>
     
	 <li> <a href="ma.php">Mattress Cleaning</a></li>
	 </ul>
	 </div>
	 </div>
  <a href="Fs.php">Fumigation and Pest Control Service's</a>
   <a href="wu.php">Why Us</a>
    <a href="cu.php">Contacts</a>
	
	
</div>
	
</div>

</td>

</table>
</ul>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div style=background-image:url("pic/s3.jpg")>
<h1>Suit Cleaning Service's</h1>
</div>
<h2>Do you want your Suit's to be Clean?  Relax! Visit us or Contact us For more Information</h2>
<table width="600px" align="center">
<tr>
<td>
<div class="w3-content w3-section" style="max-width:400px">
<img class="mySlides" class="center"src="pic/rep.png"style="width:600px;height:300px">
<img class="mySlides" class="center"  src="p/mf.jpg"  style="width:600px;height:300px">
  <img class="mySlides" class="center"src="pic/s2.jpg" style="width:600px;height:300px">
  <img class="mySlides" class="center" src="pic/s3.jpg"  style="width:600px;height:300px;" >
  <img class="mySlides" class="center"  src="pic/s4.jpg"  style="width:600px;height:300px">


<img class="mySlides" class="center"  src="p/sf.jpg"  style="width:600px;height:300px">


</td>
</div>
</table>
<script>
var myIndex = 0;
carousel();


function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    

x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>
</div>
<div style=background-color:black>
<table width="980px" align="center">
<tr>
<th style=color:red;background-color:white;text-align:center;>Quick Contacts</th>
<th style=color:red; ></th>
<th style=color:red;background-color:white;text-align:center; >Service's</th>
<th style=color:red; ></th>
<th style=color:red; ></th>
<th style=color:red;background-color:white; >Social Media</th>
</tr>
<tr><td style=color:white;font-size:12px;>

<h3>
<b>
<li><img src="lo.PNG" WIDTH="20PX"DAVEKON PALACE LTD,Banana Town Room NO:G2</li><br>
<li><img src="PH.PNG" WIDTH="20PX"> Phone:+254 789 489 752 /+254 712 225 621</li><br>
<li><img src="E.PNG" WIDTH="20PX"> Email:revampdryc@gmail.com</li></td>
<br>
<td style=color:white;font-size:10px;><u><b><h4 style=text-align:center;>
<li><a href ="ss.php">Suit Cleaning </a></li><br><br>
<LI><a href ="cs.php">Curtain Cleaning</a></Li><br><br>
<LI><a href ="cdc.php">Comforters And Duvet</a></LI> <br><br>
<li><a href ="sp.php">Steaming and   Pressing</a></li><br>
</TD>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="home.php">Dry Cleaning</a></li><br>
<li><a href ="lss.php">Laundered Shirt</a></li><br><br>
<li><a href ="fs.php">Fumigation control</a></li><br>
<li><a href="uni.php">Uniform's Cleaning </a></li><br>
</td>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="lc.php">Leather Cleaning</a></li><br>
<li><a href ="ssc.php">Sport Shoe Cleaning </a></li><br>
<li><a href ="gc.php">Gown Cleaning</a></li><br>
<li><a href="tw.php">Towel's Cleaning</a></li>
</h4>
</td>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="so.php">Sofa Cleaning</a></li><br>
<li><a href ="cc.php">Carpet Cleaning </a></li><br>
<li><a href ="kk.php">Kitchen Appliances Cleaning</a></li><br><br>
<li> <a href="ma.php">Mattress Cleaning</a></li>
</h4>
</td>
<td style=color:white;font-size:8px;>
<td><a href="http://www.facebook.com"><img src="f.png" width="40px"></a><br><h2 style =font-size:5px;>|</h2><a href="http://www.twitter.com"><img src="twi.png" width="40px"></a><br><h2 style =font-size:5px;>|</h2><a href="http://www.google.com"><img src="g.png" width="24px"></a></td>
</tr>
</table>
</html>