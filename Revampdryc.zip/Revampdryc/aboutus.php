<!doctype html>
<html>
<title>aboutus|REVAMP Dry-Cleaner And Laundry Services</title>
<ul>
<link rel="stylesheet" href="roan1.css">
<link rel="shortcut icon" href="p/rd.ico" width="100px"/>

<div>

<table width="980px">
<tr>
<td style=text-align:center;color:white;><img src="PH.PNG" WIDTH="20PX"> +254 789 489 752 /+254 712 225 621|<img src="E.PNG" WIDTH="20PX">revampdryc@gmail.com</td>
<td><a href="http://www.facebook.com"><img src="f.png" width="40px"></a><a href="http://www.twitter.com"><img src="twi.png" width="40px"></a><a href="http://www.google.com"><img src="g.png" width="24px"></a></td>
<td><h2 style=font-size:12px;>Mon-Sat:7am-7pm</h2></td>
</tr>
</table>
</div>

<body>
<table width="1000px" align="center" style= background-image:url("pic/dv1.jpg");>

<td style="text-align:center;">  <img src="pic/rep.png" width="250px" height="180px" align="middle"></td>
<td style=font-family:bold;><div class="navbar">
  <a href="home.php">Home</a></B>
  <a href="aboutus.php">About Us</a>
  <div class="dropdown">
    <button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Dry-Cleaning Service's 
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="ss.php">Suit Cleaning</a></li>
     <li><a href="cs.php">Curtain Cleaning</a></li>
     <li> <a href="cdc.php">Comforter And Duvet Cleaning</a></li>
	 <br>
	 <br>
	 
	 <li> <a href="sp.php">Steaming and Pressing</a><li>
	  
	  <li><a href="lss.php">Laundered Shirt Service </a></li>
	  <br>
	  <br>
	  <li><a href="lc.php">Leather Cleaning</a></li>
	 <li><a href="ssc.php">Sport Shoe Cleaning</a></li>
	  <li><a href="gc.php">Gown Cleaning </a></li>
	  <br>
	  <br>
	  <li><a href="uni.php">Uniform's Cleaning Service's</a></li>
	 <li><a href="tw.php">Towel's Cleaning Service's</a></li>
	  </ul>
    </div>
  </div> 
  <div class="dropdown">
	<button class="dropbtn"><img src ="pic/U.png" width="15px" align="right">Home Cleaning Service's
    </button>
    <div class="dropdown-content" style=text-align:left;>
	<ul>
     <li> <a href="so.php">Sofa Cleaning</a></li>
	 <li> <a href="kk.php">Kitchen Appliances and KitchenWare Cleaning</a></li>
	 <br>
	 <br>
     <li><a href="cc.php">Carpet Cleaning</a></li>
     
	 <li> <a href="ma.php">Mattress Cleaning</a></li>
	 </ul>
	 </div>
	 </div>
  <a href="Fs.php">Fumigation and Pest Control Service's</a>
   <a href="wu.php">Why Us</a>
    <a href="cu.php">Contacts</a>
	
	
</div>
	
</div>

</td>

</table>
</ul>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</table>
<div style=background-image:url("p/a.jpg")>
<h1>About US
<br>
<br>
</h1>
</div>
<H2 STYLE=FONT-SIZE:15PX;color:red;>Who We Are?


</h2>
<br>
 <H2 STYLE=FONT-SIZE:15PX;>

REVAMP Dry Cleaners has been setting the standard for quality garment care , Pest control and Home cleaning services. Our mission is to provide consistent quality clothing care with knowledgeable and friendly service. Dry cleaning is a daunting chore so at REVAMP, we endeavor to  make your visit as quick and easy as possible without compromising quality and service.

 

The dry cleaning technology used at REVAMP complies with the most stringent international standards to ensure that your garments will be restored to a standard appearance that rivals new clothes. This kind of an almost obsessive attention to detail is what our work and service ethics are based on.

 
</H2>
<H2 STYLE=FONT-SIZE:15PX;color:red;>
Why we're DIFFERENT?

</h2>

 <H2 STYLE=FONT-SIZE:15PX;>

We realize and appreciate the investment you’ve made in your wardrobe. That is why your clothing will always undergo our

7-POINT CHECK PROCESS while in our care. Our specialized inspection starts the minute we receive your garments. We check

 for spots, stains, cracked or missing buttons and loose threads some of which we repair for free.

 

Your health and the environment are a major concern to us. That is why we have invested in internationally certified solvents, detergents and machinery for all our washes. Our cleaning agents are Eco-friendly and Hypoallergenic to ensure safety to health and nature as well.

 

Our garment experts have, over the years perfected service delivery and customer relations owing to a specific set of services offered at REVAMP Dry Cleaners.
We also offer Pick and drop Service's to our Client
</h2>
<div style=background-color:black>
<table width="980px" align="center">
<tr>
<th style=color:red;background-color:white;text-align:center;>Quick Contacts</th>
<th style=color:red; ></th>
<th style=color:red;background-color:white;text-align:center; >Service's</th>
<th style=color:red; ></th>
<th style=color:red; ></th>
<th style=color:red;background-color:white; >Social Media</th>
</tr>
<tr><td style=color:white;font-size:12px;>

<h3>
<b>
<li><img src="lo.PNG" WIDTH="20PX">DAVEKON PALACE LTD,Banana Town Room NO:G2 </li><br>
<li><img src="PH.PNG" WIDTH="20PX"> Phone:+254 789 489 752 /+254 712 225 621</li><br>
<li><img src="E.PNG" WIDTH="20PX"> Email:revampdryc@gmail.com</li></td>
<br>
<td style=color:white;font-size:10px;><u><b><h4 style=text-align:center;>
<li><a href ="ss.php">Suit Cleaning </a></li><br><br>
<LI><a href ="cs.php">Curtain Cleaning</a></Li><br><br>
<LI><a href ="cdc.php">Comforters And Duvet</a></LI> <br><br>
<li><a href ="sp.php">Steaming and   Pressing</a></li><br>
</TD>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="home.php">Dry Cleaning</a></li><br>
<li><a href ="lss.php">Laundered Shirt</a></li><br><br>
<li><a href ="fs.php">Fumigation control</a></li><br>
<li><a href="uni.php">Uniform's Cleaning </a></li><br>
</td>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="lc.php">Leather Cleaning</a></li><br>
<li><a href ="ssc.php">Sport Shoe Cleaning </a></li><br>
<li><a href ="gc.php">Gown Cleaning</a></li><br>
<li><a href="tw.php">Towel's Cleaning</a></li>
</h4>
</td>
<TD style=color:white;font-size:10px; >
<h4>
<li><a href ="so.php">Sofa Cleaning</a></li><br>
<li><a href ="cc.php">Carpet Cleaning </a></li><br>
<li><a href ="kk.php">Kitchen Appliances Cleaning</a></li><br><br>
<li> <a href="ma.php">Mattress Cleaning</a></li>
</h4>
</td>
<td style=color:white;font-size:8px;>
<td><a href="http://www.facebook.com"><img src="f.png" width="40px"></a><br><h2 style =font-size:5px;>|</h2><a href="http://www.twitter.com"><img src="twi.png" width="40px"></a><br><h2 style =font-size:5px;>|</h2><a href="http://www.google.com"><img src="g.png" width="24px"></a></td>
</tr>
</table>
</html>