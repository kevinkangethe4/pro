<html>
<title>registration</title>
<link rel=stylesheet href="reg.css">
<body>
<br>
<h1 style=text-align:center;> Registration Form</h1>

<form>
<table width="500" height="30" style=text-align:center;background-color:lightgrey;transform:translate(50%,05%);0px;padding:50px 50px;>

<tr>
<td><input type="text" placeholder="first Name" id="firstname" name="firstname"></td></tr>
<tr>
<td><input type="text" placeholder="Last Name" id="lastname" name="lastname"></td></tr>
<tr>
<td><input type="email" placeholder="Email" id="email" name="email"></td></tr>
<tr>
<td><input type="text" placeholder="Password" id="password" name="password"></td></tr>
<tr>
<td><h2> Date of birth</h2></td></tr>
<tr>
<td><input type="date" placeholder="Date Of Birth" id="dob" name="dob"></td></tr>
</table>
</form>
</body>
</html>