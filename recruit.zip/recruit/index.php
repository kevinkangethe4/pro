<?php
header("location:reg.php");
?>